package gc.sw.photoera;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

public class PlayActivity extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    ImageView imageView;
    SeekBar seekBar;
    Button btn_login_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        imageView = (ImageView)findViewById(R.id.imageView);
        seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(this);
        btn_login_back = (Button)findViewById(R.id.btn_login_back);
        btn_login_back.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_login_back){
            finish();
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
        if (progress == 0) {
            imageView.setImageResource(R.drawable.d);
        } else if (progress == 1) {
            imageView.setImageResource(R.drawable.f);
        } else if (progress == 2) {
            imageView.setImageResource(R.drawable.s);
        } else if (progress == 3) {
            imageView.setImageResource(R.drawable.z);
        } else if (progress == 4) {
            imageView.setImageResource(R.drawable.plus);
        } else {
            imageView.setImageResource(R.drawable.sangwoo);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
