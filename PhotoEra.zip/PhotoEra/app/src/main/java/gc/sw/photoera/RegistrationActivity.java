package gc.sw.photoera;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn_registration;
    Button btn_cancel;
    ImageView regis_profile;
    boolean flag=true;
    EditText regis_id;
    EditText regis_password;
    EditText regis_password2;
    EditText regis_name;
    EditText regis_birth;
    EditText regis_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        btn_registration= (Button)findViewById(R.id.btn_registration);
        btn_registration.setOnClickListener(this);
        btn_cancel = (Button)findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(this);
        regis_profile = (ImageView)findViewById(R.id.regis_profile);
        regis_profile.setOnClickListener(this);

        regis_id = (EditText)findViewById(R.id.regis_id);
        regis_password = (EditText)findViewById(R.id.regis_password);
        regis_password2 = (EditText)findViewById(R.id.regis_password2);
        regis_name = (EditText)findViewById(R.id.regis_name);
        regis_birth = (EditText)findViewById(R.id.regis_birth);
        regis_email = (EditText)findViewById(R.id.regis_email);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_registration) {

            if (regis_password.getText().toString().equals("") ||regis_password2.getText().toString().equals("")||regis_id.getText().toString().equals("")||regis_name.getText().toString().equals("")||
                    regis_birth.getText().toString().equals("") || regis_email.getText().toString().equals("")) {
                Toast.makeText(this, "작성하지 않은 칸이 존재합니다!", Toast.LENGTH_LONG).show();
            }  else if (!regis_password.getText().toString().equals(regis_password2.getText().toString())) {
                Toast.makeText(this, "패스워드와 확인이 일치하지 않습니다!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "회원가입에 성공했습니다!", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else if (v.getId() == R.id.btn_cancel) {
            finish();
        } else if (v.getId() == R.id.regis_profile) {
            if(flag==true) {
                regis_profile.setImageResource(R.drawable.sangwoo);
                flag=false;
            }
            else {
                regis_profile.setImageResource(R.drawable.plus);
                flag=true;
            }
        }

    }
}
