package gc.sw.photoera;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FindAccountActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn_find_id;
    Button btn_find_password;
    Button btn_back;
    EditText find_id_by_email;
    EditText find_pass_by_id;
    EditText find_pass_by_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_account);

        btn_find_id = (Button)findViewById(R.id.btn_find_id);
        btn_find_id.setOnClickListener(this);
        btn_find_password = (Button)findViewById(R.id.btn_find_password);
        btn_find_password.setOnClickListener(this);
        btn_back = (Button)findViewById(R.id.btn_back);
        btn_back.setOnClickListener(this);
        find_id_by_email = (EditText)findViewById(R.id.find_id_by_email);
        find_pass_by_id = (EditText)findViewById(R.id.find_pass_by_id);
        find_pass_by_email = (EditText)findViewById(R.id.find_pass_by_email);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_find_id) {
            if (find_id_by_email.getText().toString().equals("") ) {
                Toast.makeText(this, "작성하지 않은 칸이 존재합니다!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "귀하의 아이디는 OOO 입니다.", Toast.LENGTH_LONG).show();
            }
        } else if (v.getId() == R.id.btn_find_password) {
            if (find_pass_by_id.getText().toString().equals("") || find_pass_by_email.getText().toString().equals("")) {
                Toast.makeText(this, "작성하지 않은 칸이 존재합니다!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "귀하의 비밀번호는 OOO 입니다.", Toast.LENGTH_LONG).show();
            }
        } else if (v.getId() == R.id.btn_back) {
            finish();
        }

    }
}
