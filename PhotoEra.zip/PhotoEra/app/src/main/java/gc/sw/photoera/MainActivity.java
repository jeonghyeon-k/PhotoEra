package gc.sw.photoera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView label_regis;
    TextView label_find;
    Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label_regis = (TextView)findViewById(R.id.label_regis);
        label_regis.setOnClickListener(this);
        label_find = (TextView)findViewById(R.id.label_find);
        label_find.setOnClickListener(this);
        btn_login = (Button)findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.label_regis) {
            Intent i = new Intent(this,RegistrationActivity.class);
            startActivity(i);
        } else if (v.getId() == R.id.label_find) {
            Intent j = new Intent(this,FindAccountActivity.class);
            startActivity(j);
        } else if (v.getId() == R.id.btn_login) {
            Intent k = new Intent(this,PlayActivity.class);
            startActivity(k);
        }
    }
}
